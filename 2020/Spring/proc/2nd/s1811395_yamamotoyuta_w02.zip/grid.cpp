#include <iostream>
#include <fstream>
using namespace std;

int grid(int data[5][5], int count)
{
  bool not0 = false;
  //出力配列の準備
  int out[5][5];
  for (int i = 0; i < 5; i++)
  {
    for (int j = 0; j < 5; j++)
    {
      out[i][j] = 0;
    }
  }

  //計算
  for (int i = 1; i < 4; i++)
  {
    for (int j = 1; j < 4; j++)
    {
      out[i][j] = ((data[i - 1][j] + data[i + 1][j] + data[i][j - 1] + data[i][j + 1]) % 2 == 1) ? 1 : 0;
    }
  }

  //ループ判定
  for (int i = 0; i < 5; i++)
  {
    for (int j = 0; j < 5; j++)
    {
      if (out[i][j] != 0)
      {
        not0 = true;
        break;
      }
    }
    if (not0 == true)
      break;
  }

  if (not0 == true)
  {
    count++;
    return grid(out, count);
  }
  else
  {
    return count;
  }
}

int main()
{
  cin.tie(0);
  ios::sync_with_stdio(false);

  //ここから
  int cases;
  std::cin >> cases; //input cases

  for (int n = 0; n < cases; n++)
  {
    //配列の初期化
    int data[5][5];
    int count = 0;
    for (int i = 0; i < 5; i++)
    {
      for (int j = 0; j < 5; j++)
      {
        data[i][j] = 0;
      }
    }

    //配列へのデータ投入
    string x, y, z;
    cin >> x >> y >> z;
    int N[9];
    N[0] = (int)(x[0] - '0');
    N[1] = (int)(x[1] - '0');
    N[2] = (int)(x[2] - '0');
    N[3] = (int)(y[0] - '0');
    N[4] = (int)(y[1] - '0');
    N[5] = (int)(y[2] - '0');
    N[6] = (int)(z[0] - '0');
    N[7] = (int)(z[1] - '0');
    N[8] = (int)(z[2] - '0');
    int ncount = 0;
    for (int i = 0; i < 3; i++)
    {
      for (int j = 0; j < 3; j++)
      {
        data[i+1][j+1] = N[ncount];
        ++ncount;
      }
    }

    //関数実行
    bool not0 = false;
    while(not0 == false)
    {
      for(int i = 0; i < 3; i++)
      {
        for(int j = 0; j < 3; j++)
        {
          if (data[i+1][j+1] != 0) not0 = true;
        }
      }
      break;
    }
    count = (not0 == true) ? grid(data, count) : -1;

    //output
    std::cout << count << "\n";
  }
}